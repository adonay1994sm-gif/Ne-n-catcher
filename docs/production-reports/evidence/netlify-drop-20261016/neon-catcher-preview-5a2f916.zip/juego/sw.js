const CACHE_PREFIX = "neon-preview-v1:" + self.registration.scope + "::";
const CACHE = CACHE_PREFIX + "e69dd9b711215c019d52b88597b52a54ec6d1f83efab711d99d2a1096f18209d";
const CORE = [
  "preview-config.js",
  "./",
  "index.html",
  "styles.css?v=7.2.0",
  "native-admob.js?v=7.2.0",
  "ads-config.js?v=7.2.0",
  "ad-bridge.js?v=7.2.0",
  "analytics-manager.js?v=7.2.0",
  "core-runtime.js?v=7.2.0",
  "content-runtime.js?v=7.2.0",
  "game.js?v=7.2.0",
  "manifest.webmanifest",
  "privacy.html",
  "terms.html",
  "assets/icon-192.png",
  "assets/icon-512.png",
  "assets/ship_frame_00.webp",
  "assets/ship_frame_01.webp",
  "assets/ship_frame_02.webp",
  "assets/ship_frame_03.webp",
  "assets/ship_frame_04.webp",
  "assets/ship_frame_05.webp",
  "assets/core_frame_00.webp",
  "assets/core_frame_01.webp",
  "assets/core_frame_02.webp",
  "assets/core_frame_03.webp",
  "assets/core_frame_04.webp",
  "assets/core_frame_05.webp",
  "assets/cronium_fragment_v1.webp",
  "assets/phaser_frame_00.webp",
  "assets/phaser_frame_01.webp",
  "assets/phaser_frame_02.webp",
  "assets/phaser_frame_03.webp",
  "assets/phaser_frame_04.webp",
  "assets/phaser_frame_05.webp",
  "assets/tractor_frame_00.webp",
  "assets/tractor_frame_01.webp",
  "assets/tractor_frame_02.webp",
  "assets/tractor_frame_03.webp",
  "assets/tractor_frame_04.webp",
  "assets/tractor_frame_05.webp",
  "assets/impact_frame_00.webp",
  "assets/impact_frame_01.webp",
  "assets/impact_frame_02.webp",
  "assets/impact_frame_03.webp",
  "assets/smoke_frame_00.webp",
  "assets/smoke_frame_01.webp",
  "assets/smoke_frame_02.webp",
  "assets/explosion_frame_00.webp",
  "assets/explosion_frame_01.webp",
  "assets/explosion_frame_02.webp",
  "assets/explosion_frame_03.webp",
  "assets/explosion_frame_04.webp",
  "assets/explosion_frame_05.webp",
  "assets/explosion_frame_06.webp",
  "assets/explosion_frame_07.webp",
  "assets/meteor_small.webp",
  "assets/meteor_small_alt.webp",
  "assets/meteor_medium.webp",
  "assets/meteor_medium_alt.webp",
  "assets/meteor_large.webp",
  "assets/ch01_atlas_v1.webp",
  "assets/comet_animation_sheet_v1.webp",
  "assets/debris_metal.webp",
  "assets/debris_panel.webp",
  "assets/debris_hot_00.webp",
  "assets/debris_hot_01.webp",
  "assets/satellite_old.webp",
  "assets/repair_drone.webp",
  "assets/shield_effect.webp",
  "assets/shield_idle.webp",
  "assets/explosion_small.webp",
  "assets/cronos_level1_background.webp"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(CORE)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE).map((key) => caches.delete(key))))
  );
  self.clients.claim();
});

async function networkFirst(request) {
  try {
    const response = await fetch(request, { cache: "no-store" });
    if (response?.status === 200) {
      const copy = response.clone();
      const cache = await caches.open(CACHE);
      await cache.put(request, copy);
    }
    return response;
  } catch {
    return (await (await caches.open(CACHE)).match(request)) || (request.mode === "navigate" ? (await caches.open(CACHE)).match(new URL("index.html", self.registration.scope).href) : undefined);
  }
}

async function cacheFirst(request) {
  const cached = await (await caches.open(CACHE)).match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response?.status === 200) {
    const copy = response.clone();
    const cache = await caches.open(CACHE);
    await cache.put(request, copy);
  }
  return response;
}

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || !url.href.startsWith(self.registration.scope)) return;
  const isCode = event.request.mode === "navigate" || /\.(?:html|js|css)$/.test(url.pathname);
  event.respondWith(isCode ? networkFirst(event.request) : cacheFirst(event.request));
});
