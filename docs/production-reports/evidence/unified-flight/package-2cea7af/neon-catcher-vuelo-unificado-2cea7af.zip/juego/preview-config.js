/* Preview-only storage; the ordinary game and settings are untouched. */
window.NeonPreview = Object.freeze({
  commit: "2cea7af9dcec78d2e71305526bb33cc5f31752c6", dirty: false, storagePrefix: "neon-preview-v1:",
  storage: Object.freeze({
    getItem(key) { return localStorage.getItem("neon-preview-v1:" + key); },
    setItem(key, value) { localStorage.setItem("neon-preview-v1:" + key, value); },
    removeItem(key) { localStorage.removeItem("neon-preview-v1:" + key); }
  })
});
// Direct links into the game must also prepare the offline mode selector.
if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
  const workerURL = new URL("../launcher-sw.js", document.currentScript.src);
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(workerURL.href, {scope: new URL("./", workerURL).href}).catch(() => {});
  });
}
