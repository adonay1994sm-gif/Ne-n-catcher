const CACHE_PREFIX = "neon-preview-launcher-v1:" + self.registration.scope + "::";
const CACHE = CACHE_PREFIX + "3ab2e4eb9b54164b0f63eb7d7d2148cc39680f0d6cf3411f39b508f0e1d0ae53";
const CORE = ["./", "index.html", "manifest.webmanifest", "build-info.json",
  "juego/assets/ship_frame_01.webp", "juego/assets/icon-192.png", "juego/assets/icon-512.png"]
  .map(path => new URL(path, self.registration.scope).href);
const ALLOWED = new Set(CORE);
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(CACHE_PREFIX) && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  url.search = "";
  url.hash = "";
  if (!ALLOWED.has(url.href)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(event.request, {cache: "no-store"});
      if (response.status === 200) await cache.put(url.href, response.clone());
      return response;
    } catch (error) {
      const cached = await cache.match(url.href);
      if (cached) return cached;
      throw error;
    }
  })());
});
