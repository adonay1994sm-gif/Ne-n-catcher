window.NeonNativeAds = Object.freeze({isAvailable: () => false});
