const CACHE_PREFIX = "neon-preview-launcher-v1:" + self.registration.scope + "::";
const CACHE = CACHE_PREFIX + "126430c4b02fee964f1f11827544925a66f1c6b9503486c16990855b2f1486fb";
const CORE = ["./", "index.html", "manifest.webmanifest", "build-info.json",
  "juego/assets/player_ship_identity_v1.webp", "juego/assets/icon-192.png", "juego/assets/icon-512.png"]
  .map(path => new URL(path, self.registration.scope).href);
const ALLOWED = new Set(CORE);
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(CACHE_PREFIX) && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  url.search = "";
  url.hash = "";
  if (!ALLOWED.has(url.href)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(event.request, {cache: "no-store"});
      if (response.status === 200) await cache.put(url.href, response.clone());
      return response;
    } catch (error) {
      const cached = await cache.match(url.href);
      if (cached) return cached;
      throw error;
    }
  })());
});
